create definer = root@localhost trigger deleteCartProducts
    after insert
    on ordenes
    for each row
BEGIN
    DELETE FROM carretilla WHERE usercod = NEW.clienteId;
END;

