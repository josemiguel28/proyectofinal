create definer = root@localhost view getallservicios as
select `ecommerce`.`servicios`.`servicioid`                AS `servicioId`,
       `ecommerce`.`servicios`.`servicioNombre`            AS `servicioNombre`,
       `ecommerce`.`servicios`.`servicioDescripcion`       AS `servicioDescripcion`,
       `ecommerce`.`servicios`.`servicioPrecio`            AS `servicioPrecio`,
       `ecommerce`.`servicios`.`servicioImagen`            AS `servicioImagen`,
       `ecommerce`.`servicios`.`stock`                     AS `stock`,
       `ecommerce`.`serviciotipo`.`servicioTipoDesc`       AS `servicioTipo`,
       `ecommerce`.`servicioplataforma`.`plataformaNombre` AS `servicioPlataforma`,
       `ecommerce`.`serviciocategoria`.`categoriaNombre`   AS `servicioCategoria`,
       case
           when `ecommerce`.`servicios`.`stock` > 25 then 'bg-green-700'
           when `ecommerce`.`servicios`.`stock` > 15 then 'bg-yellow-700'
           else 'bg-red-700' end                           AS `stockStatus`
from (((`ecommerce`.`servicios` join `ecommerce`.`serviciotipo` on (`ecommerce`.`serviciotipo`.`servicioTipoId` =
                                                                    `ecommerce`.`servicios`.`servicioTipoId`)) join `ecommerce`.`servicioplataforma`
       on (`ecommerce`.`servicioplataforma`.`plataformaId` =
           `ecommerce`.`servicios`.`plataformaId`)) join `ecommerce`.`serviciocategoria`
      on (`ecommerce`.`serviciocategoria`.`categoriaId` = `ecommerce`.`servicios`.`categoriaId`));

