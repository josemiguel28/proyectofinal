create definer = root@localhost view getps4products as
select `ecommerce`.`servicios`.`servicioNombre`            AS `productoNombre`,
       `ecommerce`.`servicios`.`servicioDescripcion`       AS `productoDescripcion`,
       `ecommerce`.`servicios`.`servicioPrecio`            AS `productoPrecio`,
       `ecommerce`.`servicios`.`servicioImagen`            AS `productoImagen`,
       `ecommerce`.`serviciotipo`.`servicioTipoDesc`       AS `productoTipoDesc`,
       `ecommerce`.`servicioplataforma`.`plataformaNombre` AS `plataformaNombre`
from ((`ecommerce`.`servicios` join `ecommerce`.`serviciotipo` on (`ecommerce`.`serviciotipo`.`servicioTipoId` =
                                                                   `ecommerce`.`servicios`.`servicioTipoId`)) join `ecommerce`.`servicioplataforma`
      on (`ecommerce`.`servicioplataforma`.`plataformaId` = `ecommerce`.`servicios`.`plataformaId`))
where `ecommerce`.`servicioplataforma`.`plataformaNombre` = 'PS4';

