create
    definer = root@localhost procedure sp_getServiciosById(IN p_servicioId int)
begin
    select servicios.servicioId as servicioId,
           servicios.servicioNombre as servicioNombre,
           servicios.servicioDescripcion,
           servicios.servicioPrecio,
           servicios.servicioImagen,
           servicios.stock,
           serviciotipo.servicioTipoDesc,
           servicioplataforma.plataformaNombre,
           serviciocategoria.categoriaNombre


    from servicios

             join serviciotipo on serviciotipo.servicioTipoId = servicios.servicioTipoId
             join servicioplataforma on servicioplataforma.plataformaId = servicios.plataformaId
             join serviciocategoria on serviciocategoria.categoriaId = servicios.categoriaId
    where servicios.servicioId = p_servicioId;
end;

