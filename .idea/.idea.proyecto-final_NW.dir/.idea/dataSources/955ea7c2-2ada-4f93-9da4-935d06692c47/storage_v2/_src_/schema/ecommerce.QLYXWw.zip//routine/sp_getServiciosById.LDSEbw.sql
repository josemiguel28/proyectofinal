create
    definer = root@localhost procedure sp_getServiciosById(IN p_servicioId int)
begin
    select servicios.servicioId,
           servicios.servicioNombre,
           servicios.servicioDescripcion,
           servicios.servicioPrecio,
           servicios.servicioImagen,
           servicios.stock,
           serviciotipo.servicioTipoDesc,
           productoplataforma.plataformaNombre,
           productocategoria.categoriaNombre


    from servicios

             join serviciotipo on serviciotipo.servicioTipoId = servicios.servicioTipoId
             join productoplataforma on productoplataforma.plataformaId = servicios.plataformaId
             join productocategoria on productocategoria.categoriaId = servicios.categoriaId
    where servicios.servicioId = p_servicioId;
end;

