create definer = root@localhost view getallservicios as
select `ecommerce`.`servicios`.`servicioNombre`            AS `productoNombre`,
       `ecommerce`.`servicios`.`servicioDescripcion`       AS `productoDescripcion`,
       `ecommerce`.`servicios`.`servicioPrecio`            AS `productoPrecio`,
       `ecommerce`.`servicios`.`servicioImagen`            AS `productoImagen`,
       `ecommerce`.`servicios`.`stock`                     AS `stock`,
       `ecommerce`.`serviciotipo`.`servicioTipoDesc`       AS `productoTipo`,
       `ecommerce`.`productoplataforma`.`plataformaNombre` AS `productoPlataforma`,
       `ecommerce`.`productocategoria`.`categoriaNombre`   AS `productoCategoria`
from (((`ecommerce`.`servicios` join `ecommerce`.`serviciotipo` on (`ecommerce`.`serviciotipo`.`servicioTipoId` =
                                                                    `ecommerce`.`servicios`.`servicioTipoId`)) join `ecommerce`.`productoplataforma`
       on (`ecommerce`.`productoplataforma`.`plataformaId` =
           `ecommerce`.`servicios`.`plataformaId`)) join `ecommerce`.`productocategoria`
      on (`ecommerce`.`productocategoria`.`categoriaId` = `ecommerce`.`servicios`.`categoriaId`));

